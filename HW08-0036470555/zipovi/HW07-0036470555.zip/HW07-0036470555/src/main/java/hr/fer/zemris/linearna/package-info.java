/**
 * Implementations for created library.
 */
/**
 * @author Ivan Pavić
 *
 */
package hr.fer.zemris.linearna;